# README

将 bin/ 加入到系统环境变量 PATH 中

